package br.ulbra.trocadetela;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    ImageView imgfoto2;
    Button btnFoto1, btnFoto2;
    TextView txtFoto1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        imgfoto2 = (ImageView) findViewById(R.id.imgfoto2);
        btnFoto1 = (Button) findViewById(R.id.btnFoto1);
        btnFoto2 = (Button) findViewById(R.id.btnFoto2);
        txtFoto1 = (TextView) findViewById(R.id.txtFoto1);
        btnFoto1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                imgfoto2.setImageResource(R.drawable.foto2);
                txtFoto1.setText("Foto 1");
            }
        });

        btnFoto2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                imgfoto2.setImageResource(R.drawable.miau1);
                txtFoto1.setText("Foto 2 ");

            }
        });
    }
}


